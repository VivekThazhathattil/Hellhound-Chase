Thank you for downloading this pack!
If you wish to donate in order to support my work you can do so via paypal: jestan@outlook.pt

Check license details here:
https://creativecommons.org/licenses/by-sa/4.0/

Enjoy!